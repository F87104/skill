#!/usr/bin/env python3
"""
Substack 自動いいね＆フォローツール（安全版 v2）
人間らしい動作パターンでアカウント凍結を防止する

使用方法:
    python main.py --config config.json --mode all
    python main.py --config config.json --mode all --dry-run
    python main.py --test
"""

import argparse
import logging
import sys
import json
from pathlib import Path
from datetime import date

from substack_client import SubstackClient
from auto_liker import AutoLiker


def setup_logging(verbose: bool = False, log_file: str = None):
    """ロギング設定"""
    level = logging.DEBUG if verbose else logging.INFO
    handlers = [logging.StreamHandler(sys.stdout)]

    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))

    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
    )


def load_config(config_path: str = "config.json") -> dict:
    """設定ファイルを読み込む"""
    path = Path(config_path)
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_config_template(config_path: str = "config.json"):
    """設定ファイルのテンプレートを作成（安全版）"""
    template = {
        "cookie": "YOUR_SUBSTACK_SID_COOKIE_HERE",
        "max_likes_per_mode": 8,
        "max_follows": 3,
        "daily_like_limit": 50,
        "daily_follow_limit": 5,
        "modes": ["recommend", "follower", "return"],
        "enable_follow": True,
        "dry_run": False,
        "log_file": "auto_liker.log",
        "state_file": "like_state.json",
        "follow_state_file": "follow_state.json",
        "schedule_interval_minutes": 480,
        "quiet_hours_start": 0,
        "quiet_hours_end": 8,
        "safety": {
            "description": "安全版 - 人間らしい動作パターン",
            "1回あたり": "各モード8件 × 3モード = 最大24件いいね + 3件フォロー",
            "1日の上限": "いいね50件、フォロー5件（日次カウンターで厳密管理）",
            "待機時間": "いいね間5-25秒、モード間30-120秒、フォロー間30-90秒",
            "安全機能": "レート制限2回で3時間停止、エラー3回で6時間停止"
        }
    }
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(template, f, ensure_ascii=False, indent=2)
    print(f"設定テンプレートを作成しました: {config_path}")
    print("cookie の値をブラウザのDevToolsから取得して設定してください。")


def main():
    parser = argparse.ArgumentParser(
        description="Substack 自動いいね＆フォローツール（安全版）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  # 全モード実行（いいね + フォロー）
  python main.py --config config.json --mode all

  # ドライラン（実際には実行しない）
  python main.py --config config.json --mode all --dry-run

  # いいねのみ
  python main.py --config config.json --mode likes-all

  # フォローのみ
  python main.py --config config.json --mode follow

  # 接続テスト
  python main.py --test

  # 本日の残り確認
  python main.py --status

  # 統計情報
  python main.py --stats
        """
    )

    parser.add_argument("--cookie", "-c", help="substack.sid クッキーの値")
    parser.add_argument("--config", help="設定ファイルのパス", default="config.json")
    parser.add_argument("--init", action="store_true", help="設定テンプレートを作成")
    parser.add_argument(
        "--mode", "-m",
        choices=["recommend", "follower", "return", "likes-all", "follow", "followback", "all"],
        default="all",
        help="実行モード (default: all)"
    )
    parser.add_argument("--max-likes", "-n", type=int, help="最大いいね数/モード (default: 8)")
    parser.add_argument("--max-follows", type=int, help="最大フォロー数 (default: 3)")
    parser.add_argument("--dry-run", "-d", action="store_true", help="ドライラン（実際には実行しない）")
    parser.add_argument("--test", "-t", action="store_true", help="接続テスト")
    parser.add_argument("--stats", "-s", action="store_true", help="統計情報を表示")
    parser.add_argument("--status", action="store_true", help="本日の残り件数を表示")
    parser.add_argument("--verbose", "-v", action="store_true", help="詳細ログ出力")
    parser.add_argument("--log-file", help="ログファイルパス")
    parser.add_argument("--state-file", default="like_state.json", help="状態ファイルパス")

    args = parser.parse_args()

    # 設定テンプレート作成
    if args.init:
        save_config_template(args.config)
        return

    # 設定読み込み
    config = load_config(args.config)

    # 統計情報表示
    if args.stats:
        state_file = Path(args.state_file)
        if state_file.exists():
            with open(state_file, "r", encoding="utf-8") as f:
                state = json.load(f)
            print("\n=== Substack 自動いいね 統計情報 ===")
            print(f"最終実行: {state.get('last_run', '未実行')}")
            stats = state.get("stats", {})
            print(f"累計いいね数: {stats.get('total_likes_given', 0)}")
            print(f"  おすすめ: {stats.get('recommend_likes', 0)}")
            print(f"  フォロワー: {stats.get('follower_likes', 0)}")
            print(f"  お返し: {stats.get('return_likes', 0)}")
            print(f"いいね済み投稿数: {len(state.get('liked_post_ids', []))}")
            print(f"いいね済みノート数: {len(state.get('liked_note_ids', []))}")
            print(f"お返し済みユーザー数: {len(state.get('returned_likes_to', []))}")
            print("=" * 40)
        else:
            print("状態ファイルが見つかりません。まだ実行されていません。")

        follow_state_file = Path(config.get("follow_state_file", "follow_state.json"))
        if follow_state_file.exists():
            with open(follow_state_file, "r", encoding="utf-8") as f:
                fstate = json.load(f)
            print(f"\n=== フォロー統計 ===")
            print(f"累計フォロー数: {fstate.get('total_follows', 0)}")
            print(f"フォロー済みユーザー数: {len(fstate.get('followed_user_ids', []))}")
            print("=" * 40)

        # 日次状況も表示
        daily_file = Path("daily_limits.json")
        if daily_file.exists():
            with open(daily_file, "r", encoding="utf-8") as f:
                daily = json.load(f)
            if daily.get("date") == str(date.today()):
                print(f"\n=== 本日の実行状況 ({daily['date']}) ===")
                print(f"いいね: {daily.get('likes_today', 0)}件")
                print(f"フォロー: {daily.get('follows_today', 0)}件")
                print(f"エラー: {daily.get('errors_today', 0)}件")
                print(f"レート制限: {daily.get('rate_limits_today', 0)}回")
                if daily.get("paused_until"):
                    print(f"一時停止中: {daily['paused_until']}まで")
                print("=" * 40)
        return

    # 本日の残り件数表示
    if args.status:
        daily_file = Path("daily_limits.json")
        daily_like_limit = config.get("daily_like_limit", 50)
        daily_follow_limit = config.get("daily_follow_limit", 5)

        if daily_file.exists():
            with open(daily_file, "r", encoding="utf-8") as f:
                daily = json.load(f)
            if daily.get("date") == str(date.today()):
                likes_left = max(0, daily_like_limit - daily.get("likes_today", 0))
                follows_left = max(0, daily_follow_limit - daily.get("follows_today", 0))
                print(f"\n=== 本日の残り ({daily['date']}) ===")
                print(f"いいね残り: {likes_left}/{daily_like_limit}件")
                print(f"フォロー残り: {follows_left}/{daily_follow_limit}件")
                if daily.get("paused_until"):
                    print(f"一時停止中: {daily['paused_until']}まで")
                else:
                    print("ステータス: 実行可能")
            else:
                print(f"\n本日はまだ未実行です。")
                print(f"いいね上限: {daily_like_limit}件/日")
                print(f"フォロー上限: {daily_follow_limit}件/日")
        else:
            print(f"\n本日はまだ未実行です。")
            print(f"いいね上限: {daily_like_limit}件/日")
            print(f"フォロー上限: {daily_follow_limit}件/日")
        return

    # クッキー取得（引数 > 設定ファイル）
    cookie = args.cookie or config.get("cookie")
    if not cookie or cookie == "YOUR_SUBSTACK_SID_COOKIE_HERE":
        print("エラー: substack.sid クッキーが設定されていません。")
        print("")
        print("取得方法:")
        print("  1. ブラウザでSubstackにログイン")
        print("  2. DevTools を開く (F12)")
        print("  3. Application > Cookies > substack.com")
        print("  4. 'substack.sid' の値をコピー")
        print("")
        print("使用方法:")
        print("  python main.py --cookie 'YOUR_COOKIE_VALUE' --mode all")
        print("  または")
        print("  python main.py --init  # 設定ファイルを作成")
        sys.exit(1)

    # ロギング設定
    log_file = args.log_file or config.get("log_file")
    setup_logging(args.verbose, log_file)

    # 安全設定の読み込み
    daily_like_limit = config.get("daily_like_limit", 50)
    daily_follow_limit = config.get("daily_follow_limit", 5)

    # クライアント初期化（日次制限付き）
    client = SubstackClient(
        session_cookie=cookie,
        daily_like_limit=daily_like_limit,
        daily_follow_limit=daily_follow_limit,
    )

    # 接続テスト
    if args.test:
        print("接続テスト中...")
        if client.test_connection():
            print(f"\u2713 接続成功！ユーザーID: {client.user_id}, ユーザー名: {client.username}")
            status = client.get_daily_status()
            print(f"  本日残り: いいね={status['likes_remaining']}件, フォロー={status['follows_remaining']}件")
        else:
            print("\u2717 接続失敗。クッキーの値を確認してください。")
            sys.exit(1)
        return

    # 接続確認
    logging.info("Substackに接続中...")
    if not client.test_connection():
        logging.error("接続失敗。クッキーの値を確認してください。")
        sys.exit(1)
    logging.info(f"接続成功: {client.username} (ID: {client.user_id})")

    # 日次状況表示
    status = client.get_daily_status()
    logging.info(f"本日の残り: いいね={status['likes_remaining']}件, フォロー={status['follows_remaining']}件")
    if status["is_paused"]:
        logging.warning("現在安全停止中です。時間を置いてから再実行してください。")
        sys.exit(0)

    # AutoLiker初期化
    state_file = args.state_file or config.get("state_file", "like_state.json")
    liker = AutoLiker(client, state_file=state_file)

    # 実行パラメータ（安全なデフォルト値）
    max_likes = args.max_likes or config.get("max_likes_per_mode", 8)
    max_follows = args.max_follows or config.get("max_follows", 3)
    dry_run = args.dry_run or config.get("dry_run", False)
    mode = args.mode

    # いいね実行
    like_results = {}
    follow_results = {}

    try:
        # いいねモード
        if mode in ["all", "likes-all", "recommend", "follower", "return"]:
            if mode in ["all", "likes-all"]:
                like_results = liker.run_all(max_likes_per_mode=max_likes, dry_run=dry_run)
            elif mode == "recommend":
                like_results = {"recommend": liker.like_recommended(max_likes, dry_run)}
            elif mode == "follower":
                like_results = {"follower": liker.like_follower_posts(max_likes, dry_run)}
            elif mode == "return":
                like_results = {"return": liker.like_back(max_likes, dry_run)}

        # フォローモード
        if mode in ["all", "follow", "followback"]:
            try:
                from auto_follow import AutoFollower

                follower = AutoFollower(
                    cookie=cookie,
                    email=config.get('email', ''),
                    daily_follow_limit=daily_follow_limit,
                )

                if mode in ["all", "follow"]:
                    logging.info("=== 自動フォロー（フィード）===")
                    result = follower.follow_from_feed(
                        max_follows=max_follows,
                        dry_run=dry_run
                    )
                    follow_results['follow'] = result

                if mode in ["all", "followback"]:
                    logging.info("=== フォローバック ===")
                    result = follower.follow_back(
                        max_follows=max(2, max_follows // 2),
                        dry_run=dry_run
                    )
                    follow_results['followback'] = result

            except ImportError:
                logging.warning("auto_follow.py が見つかりません。フォロー機能をスキップします。")
            except Exception as e:
                logging.error(f"フォローエラー: {e}")

        # 結果出力
        print("\n=== 実行結果 ===")

        if like_results:
            print("\n--- いいね ---")
            total_liked = 0
            for mode_name, result in like_results.items():
                liked_count = len(result['liked'])
                total_liked += liked_count
                print(f"[{mode_name}]")
                print(f"  いいね成功: {liked_count}件")
                print(f"  スキップ: {len(result['skipped'])}件")
                print(f"  失敗: {len(result['failed'])}件")
            print(f"\n  いいね合計: {total_liked}件")

        if follow_results:
            print("\n--- フォロー ---")
            for mode_name, result in follow_results.items():
                print(f"[{mode_name}]")
                print(f"  フォロー成功: {result['success']}件")
                print(f"  スキップ: {result['skip']}件")
                print(f"  失敗: {result['fail']}件")

        # 最終日次状況
        final_status = client.get_daily_status()
        print(f"\n--- 本日の残り ---")
        print(f"  いいね: {final_status['likes_remaining']}/{daily_like_limit}件")
        print(f"  フォロー: {final_status['follows_remaining']}/{daily_follow_limit}件")

    except KeyboardInterrupt:
        print("\n中断されました。")
        sys.exit(0)
    except Exception as e:
        logging.error(f"実行エラー: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
