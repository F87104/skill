#!/bin/bash
# Substack 自動いいね＆フォロー 実行スクリプト
# crontabから呼び出される
#
# 設定: 1日300件いいね + フォロー
# - 3モード × 34件 = 102件/回
# - 1日3回実行 = 306件/日
# - フォロー: 5件/回 × 3回 = 15件/日

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ログファイル
LOG_FILE="$SCRIPT_DIR/cron_log.txt"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

echo "========================================" >> "$LOG_FILE"
echo "[$DATE] 実行開始" >> "$LOG_FILE"

# いいね + フォロー 全モード実行
/usr/bin/python3 main.py --config config.json --mode all --max-likes 34 --max-follows 5 >> "$LOG_FILE" 2>&1

echo "[$DATE] 実行完了" >> "$LOG_FILE"
echo "========================================" >> "$LOG_FILE"
