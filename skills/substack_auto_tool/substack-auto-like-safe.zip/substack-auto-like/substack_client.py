"""
Substack API クライアント（安全版 v2）
人間らしいリクエストパターンでアカウント凍結を防止する
"""

import requests
import time
import json
import random
import logging
from typing import Optional, Dict, List, Any
from datetime import datetime, date

logger = logging.getLogger(__name__)


class HumanBehavior:
    """人間らしい動作パターンをシミュレートするヘルパー"""

    # User-Agentのバリエーション（Macユーザーとして自然なもの）
    USER_AGENTS = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    ]

    @staticmethod
    def reading_pause():
        """記事を読んでいるかのような待機（5-25秒、正規分布）"""
        delay = max(5.0, random.gauss(12.0, 5.0))
        delay = min(delay, 30.0)
        time.sleep(delay)

    @staticmethod
    def quick_pause():
        """軽い操作間の待機（2-8秒）"""
        delay = max(2.0, random.gauss(4.0, 1.5))
        delay = min(delay, 10.0)
        time.sleep(delay)

    @staticmethod
    def page_transition():
        """ページ遷移のような待機（30-120秒）"""
        delay = max(30.0, random.gauss(60.0, 20.0))
        delay = min(delay, 180.0)
        time.sleep(delay)

    @staticmethod
    def session_start():
        """セッション開始時の待機（ページ読み込みのフリ）"""
        time.sleep(random.uniform(3.0, 8.0))

    @staticmethod
    def should_skip(skip_rate: float = 0.25) -> bool:
        """一定確率でスキップ（人間は全部にいいねしない）"""
        return random.random() < skip_rate

    @staticmethod
    def get_random_ua() -> str:
        """ランダムなUser-Agentを返す"""
        return random.choice(HumanBehavior.USER_AGENTS)

    @staticmethod
    def burst_limit_reached(consecutive_count: int, max_burst: int = 3) -> bool:
        """連続操作の上限チェック（人間は3件連続が限度）"""
        return consecutive_count >= max_burst


class DailyLimiter:
    """日次制限管理"""

    def __init__(self, state_file: str = "daily_limits.json"):
        self.state_file = state_file
        self.state = self._load()

    def _load(self) -> dict:
        try:
            with open(self.state_file, "r") as f:
                data = json.load(f)
                # 日付が変わっていたらリセット
                if data.get("date") != str(date.today()):
                    return self._new_state()
                return data
        except (FileNotFoundError, json.JSONDecodeError):
            return self._new_state()

    def _new_state(self) -> dict:
        return {
            "date": str(date.today()),
            "likes_today": 0,
            "follows_today": 0,
            "errors_today": 0,
            "rate_limits_today": 0,
            "sessions_today": 0,
            "paused_until": None,
        }

    def save(self):
        with open(self.state_file, "w") as f:
            json.dump(self.state, f, indent=2)

    def can_like(self, daily_max: int = 50) -> bool:
        """いいね可能かチェック"""
        if self.is_paused():
            return False
        return self.state["likes_today"] < daily_max

    def can_follow(self, daily_max: int = 5) -> bool:
        """フォロー可能かチェック"""
        if self.is_paused():
            return False
        return self.state["follows_today"] < daily_max

    def record_like(self):
        self.state["likes_today"] += 1
        self.save()

    def record_follow(self):
        self.state["follows_today"] += 1
        self.save()

    def record_error(self):
        self.state["errors_today"] += 1
        # 連続エラー3回で当日停止
        if self.state["errors_today"] >= 3:
            self.pause_for_hours(6)
        self.save()

    def record_rate_limit(self):
        self.state["rate_limits_today"] += 1
        # レート制限2回で長時間停止
        if self.state["rate_limits_today"] >= 2:
            self.pause_for_hours(3)
        self.save()

    def record_session(self):
        self.state["sessions_today"] += 1
        self.save()

    def is_paused(self) -> bool:
        paused = self.state.get("paused_until")
        if paused:
            if datetime.fromisoformat(paused) > datetime.now():
                return True
            else:
                self.state["paused_until"] = None
                self.save()
        return False

    def pause_for_hours(self, hours: int):
        from datetime import timedelta
        until = datetime.now() + timedelta(hours=hours)
        self.state["paused_until"] = until.isoformat()
        logger.warning(f"安全停止: {until.strftime('%H:%M')}まで一時停止します")
        self.save()

    def get_remaining(self, daily_like_max: int = 50, daily_follow_max: int = 5) -> dict:
        return {
            "likes_remaining": max(0, daily_like_max - self.state["likes_today"]),
            "follows_remaining": max(0, daily_follow_max - self.state["follows_today"]),
            "is_paused": self.is_paused(),
        }


class SubstackClient:
    """Substack APIクライアント（安全版）"""

    BASE_URL = "https://substack.com/api/v1"

    def __init__(self, session_cookie: str, user_agent: Optional[str] = None,
                 daily_like_limit: int = 50, daily_follow_limit: int = 5):
        """
        初期化

        Args:
            session_cookie: substack.sid クッキーの値
            user_agent: カスタムUser-Agent（省略時はランダム選択）
            daily_like_limit: 1日のいいね上限
            daily_follow_limit: 1日のフォロー上限
        """
        self.session = requests.Session()
        self.session.cookies.set("substack.sid", session_cookie, domain=".substack.com")

        self.session.headers.update({
            "User-Agent": user_agent or HumanBehavior.get_random_ua(),
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Origin": "https://substack.com",
            "Referer": "https://substack.com/",
            "Accept-Language": "ja,en-US;q=0.9,en;q=0.8",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
        })

        self._user_id: Optional[int] = None
        self._username: Optional[str] = None

        # 人間らしい動作
        self.human = HumanBehavior()

        # 日次制限
        self.daily_limiter = DailyLimiter()
        self.daily_like_limit = daily_like_limit
        self.daily_follow_limit = daily_follow_limit

        # 連続操作カウンター
        self._consecutive_likes = 0

    @property
    def user_id(self) -> int:
        if self._user_id is None:
            self._fetch_own_profile()
        return self._user_id

    @property
    def username(self) -> str:
        if self._username is None:
            self._fetch_own_profile()
        return self._username

    def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        """
        人間らしい待機付きHTTPリクエスト
        """
        # 軽い待機（GETリクエスト）
        self.human.quick_pause()

        response = self.session.request(method, url, **kwargs)

        if response.status_code == 429:
            # レート制限 → 長時間停止
            self.daily_limiter.record_rate_limit()
            retry_after = int(response.headers.get("Retry-After", 300))
            wait_time = max(retry_after, 300)  # 最低5分待機
            logger.warning(f"レート制限検出。{wait_time}秒待機します...")
            time.sleep(wait_time)
            # リトライはしない（安全のため）
            response.raise_for_status()

        if response.status_code in [401, 403]:
            logger.error(f"認証/権限エラー: {response.status_code}")

        response.raise_for_status()
        return response

    def _fetch_own_profile(self):
        """自分のプロフィール情報を取得"""
        try:
            response = self._request("GET", f"{self.BASE_URL}/user/profile/self")
            data = response.json()
            self._user_id = data.get("id")
            self._username = data.get("handle") or data.get("name", "")
            logger.info(f"ユーザー情報取得: ID={self._user_id}, Name={self._username}")
            return
        except requests.HTTPError as e:
            logger.debug(f"/user/profile/self 失敗: {e}")
        except Exception as e:
            logger.debug(f"/user/profile/self エラー: {e}")

        try:
            response = self._request("GET", f"{self.BASE_URL}/activity-feed-web")
            data = response.json()
            if isinstance(data, dict):
                user = data.get("user") or data.get("currentUser")
                if user:
                    self._user_id = user.get("id")
                    self._username = user.get("handle") or user.get("name", "")
                    logger.info(f"ユーザー情報取得(activity): ID={self._user_id}, Name={self._username}")
                    return
                self._user_id = -1
                self._username = "authenticated_user"
                logger.info("認証確認成功（activity-feed取得可能）")
                return
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 401:
                raise Exception("認証に失敗しました。クッキーの値が無効または期限切れです。")
            logger.debug(f"/activity-feed-web 失敗: {e}")
        except Exception as e:
            logger.debug(f"/activity-feed-web エラー: {e}")

        try:
            response = self._request("GET", f"{self.BASE_URL}/feed/following")
            if response.status_code == 200:
                self._user_id = -1
                self._username = "authenticated_user"
                logger.info("認証確認成功（following取得可能）")
                return
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 401:
                raise Exception("認証に失敗しました。クッキーの値が無効または期限切れです。")
        except Exception:
            pass

        raise Exception("認証に失敗しました。クッキーの値を確認してください。")

    def test_connection(self) -> bool:
        """接続テスト"""
        try:
            self._fetch_own_profile()
            return True
        except Exception as e:
            logger.error(f"接続失敗。クッキーの値を確認してください。 ({e})")
            return False

    # ===== フィード取得 =====

    def get_feed(self, limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
        """おすすめフィード（ホームフィード）を取得"""
        url = f"{self.BASE_URL}/reader/feed"
        params = {"limit": limit, "offset": offset}
        try:
            response = self._request("GET", url, params=params)
            data = response.json()
            return data.get("items", data) if isinstance(data, dict) else data
        except Exception as e:
            logger.error(f"フィード取得失敗: {e}")
            return []

    def get_notes_feed(self, limit: int = 20) -> List[Dict[str, Any]]:
        """ノートフィードを取得"""
        url = f"{self.BASE_URL}/reader/feed/notes"
        params = {"limit": limit}
        try:
            response = self._request("GET", url, params=params)
            data = response.json()
            return data.get("items", data) if isinstance(data, dict) else data
        except Exception as e:
            logger.error(f"ノートフィード取得失敗: {e}")
            return []

    def get_activity(self, limit: int = 50) -> Dict[str, Any]:
        """アクティビティ（通知）を取得"""
        url = f"{self.BASE_URL}/activity-feed-web"
        try:
            response = self._request("GET", url)
            data = response.json()
            if isinstance(data, dict):
                return data
            return {"activityItems": []}
        except Exception as e:
            logger.error(f"アクティビティ取得失敗: {e}")
            return {"activityItems": []}

    def get_following_user_ids(self) -> List[int]:
        """フォローしているユーザーIDのリストを取得"""
        url = f"{self.BASE_URL}/feed/following"
        try:
            response = self._request("GET", url)
            data = response.json()
            if isinstance(data, list):
                return data
            return []
        except Exception as e:
            logger.error(f"フォローリスト取得失敗: {e}")
            return []

    def get_follower_posts(self, limit: int = 20) -> List[Dict[str, Any]]:
        """フォローしているユーザーの投稿を取得"""
        url = f"{self.BASE_URL}/reader/feed"
        params = {"limit": limit * 2, "offset": 0}
        try:
            response = self._request("GET", url, params=params)
            data = response.json()
            items = data.get("items", data) if isinstance(data, dict) else data
            if not isinstance(items, list):
                return []
            return [item for item in items if isinstance(item, dict)]
        except Exception as e:
            logger.error(f"フォロワー投稿取得失敗: {e}")
            return []

    def get_subscriptions(self) -> List[Dict[str, Any]]:
        """購読中のpublicationリストを取得"""
        url = f"{self.BASE_URL}/subscriptions/all/v2"
        try:
            response = self._request("GET", url)
            data = response.json()
            return data if isinstance(data, list) else data.get("subscriptions", [])
        except Exception as e:
            logger.error(f"購読リスト取得失敗: {e}")
            return []

    def get_user_likes(self, limit: int = 50) -> List[Dict[str, Any]]:
        """自分がいいねした投稿の一覧を取得"""
        user_id = self.user_id
        if user_id == -1:
            logger.warning("ユーザーIDが不明のため、いいね履歴を取得できません")
            return []
        url = f"{self.BASE_URL}/reader/feed/profile/{user_id}"
        params = {"types[]": "like", "limit": limit}
        try:
            response = self._request("GET", url, params=params)
            data = response.json()
            return data.get("items", data) if isinstance(data, dict) else data
        except Exception as e:
            logger.error(f"いいね履歴取得失敗: {e}")
            return []

    # ===== いいね実行（安全版） =====

    def like_post(self, post_id: int) -> bool:
        """投稿にいいねする（日次制限・バースト制限付き）"""
        # 日次制限チェック
        if not self.daily_limiter.can_like(self.daily_like_limit):
            remaining = self.daily_limiter.get_remaining(self.daily_like_limit)
            if remaining["is_paused"]:
                logger.warning("安全停止中のため、いいねをスキップします")
            else:
                logger.warning(f"本日のいいね上限({self.daily_like_limit}件)に達しました")
            return False

        # バースト制限（3件連続でいいねしたら長めの休憩）
        if self.human.burst_limit_reached(self._consecutive_likes, max_burst=3):
            logger.info("連続いいね上限に達しました。休憩します...")
            self.human.page_transition()
            self._consecutive_likes = 0

        url = f"{self.BASE_URL}/post/{post_id}/reaction"
        payload = {"reaction": "\u2764"}

        try:
            # 記事を読んでいるかのような待機
            self.human.reading_pause()
            response = self.session.post(url, json=payload, timeout=10)

            if response.status_code in [200, 201, 204]:
                logger.info(f"いいね成功: post_id={post_id}")
                self.daily_limiter.record_like()
                self._consecutive_likes += 1
                return True
            elif response.status_code == 401:
                logger.error(f"認証エラー: post_id={post_id}")
                self.daily_limiter.record_error()
                return False
            elif response.status_code == 409:
                logger.info(f"既にいいね済み: post_id={post_id}")
                return True
            elif response.status_code == 429:
                logger.warning(f"レート制限: post_id={post_id}")
                self.daily_limiter.record_rate_limit()
                return False
            else:
                logger.warning(f"いいね失敗: post_id={post_id}, status={response.status_code}")
                self.daily_limiter.record_error()
                return False
        except requests.Timeout:
            logger.error(f"タイムアウト: post_id={post_id}")
            return False
        except Exception as e:
            logger.error(f"いいねエラー: post_id={post_id}, error={e}")
            return False

    def like_comment(self, comment_id: int) -> bool:
        """コメント/ノートにいいねする（日次制限付き）"""
        if not self.daily_limiter.can_like(self.daily_like_limit):
            remaining = self.daily_limiter.get_remaining(self.daily_like_limit)
            if remaining["is_paused"]:
                logger.warning("安全停止中のため、いいねをスキップします")
            else:
                logger.warning(f"本日のいいね上限({self.daily_like_limit}件)に達しました")
            return False

        if self.human.burst_limit_reached(self._consecutive_likes, max_burst=3):
            logger.info("連続いいね上限に達しました。休憩します...")
            self.human.page_transition()
            self._consecutive_likes = 0

        url = f"{self.BASE_URL}/comment/{comment_id}/reaction"
        payload = {"reaction": "\u2764"}

        try:
            self.human.reading_pause()
            response = self.session.post(url, json=payload, timeout=10)

            if response.status_code in [200, 201, 204]:
                logger.info(f"コメントいいね成功: comment_id={comment_id}")
                self.daily_limiter.record_like()
                self._consecutive_likes += 1
                return True
            elif response.status_code == 409:
                logger.info(f"既にいいね済み: comment_id={comment_id}")
                return True
            elif response.status_code == 429:
                logger.warning(f"レート制限: comment_id={comment_id}")
                self.daily_limiter.record_rate_limit()
                return False
            else:
                logger.warning(f"コメントいいね失敗: comment_id={comment_id}, status={response.status_code}")
                self.daily_limiter.record_error()
                return False
        except Exception as e:
            logger.error(f"コメントいいねエラー: comment_id={comment_id}, error={e}")
            return False

    def like_note(self, note_id: int) -> bool:
        """ノートにいいねする"""
        return self.like_comment(note_id)

    def like_item(self, item: Dict[str, Any]) -> bool:
        """フィードアイテムにいいねする（投稿/ノート/コメント自動判定）"""
        item_type = item.get("type", "")

        if item_type in ["comment", "note"]:
            comment = item.get("comment")
            if comment and isinstance(comment, dict):
                comment_id = comment.get("id")
                if comment_id:
                    return self.like_comment(comment_id)
            item_id = item.get("id")
            if item_id:
                return self.like_comment(item_id)

        if item_type == "post" or ("post" in item and item.get("post") is not None):
            post = item.get("post")
            if post and isinstance(post, dict):
                post_id = post.get("id")
                if post_id:
                    return self.like_post(post_id)

        if "comment" in item and item.get("comment") is not None:
            comment = item["comment"]
            if isinstance(comment, dict):
                comment_id = comment.get("id")
                if comment_id:
                    return self.like_comment(comment_id)

        item_id = item.get("id") or item.get("post_id")
        if item_id:
            if item_type in ["comment", "note"]:
                return self.like_comment(item_id)
            else:
                return self.like_post(item_id)

        logger.warning(f"アイテムIDが見つかりません: {json.dumps(item, default=str)[:200]}")
        return False

    def get_item_info(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """フィードアイテムから表示用の情報を抽出"""
        item_type = item.get("type", "unknown")
        info = {"type": item_type}

        if item_type == "post" or "post" in item:
            post = item.get("post", item)
            info["id"] = post.get("id")
            info["title"] = post.get("title", "（タイトルなし）")
            info["slug"] = post.get("slug", "")
            pub = item.get("publication", {})
            info["author"] = pub.get("name", "") or post.get("publishedBylines", [{}])[0].get("name", "") if post.get("publishedBylines") else ""
        elif item_type in ["comment", "note"] or "comment" in item:
            comment = item.get("comment", item)
            info["id"] = comment.get("id")
            info["title"] = comment.get("body", "")[:50] + "..."
            context_users = item.get("context", {}).get("users", [])
            info["author"] = context_users[0].get("name", "") if context_users else ""
        else:
            info["id"] = item.get("id")
            info["title"] = item.get("title", "（不明）")
            info["author"] = ""

        return info

    def get_daily_status(self) -> dict:
        """本日の実行状況を取得"""
        return self.daily_limiter.get_remaining(self.daily_like_limit, self.daily_follow_limit)
