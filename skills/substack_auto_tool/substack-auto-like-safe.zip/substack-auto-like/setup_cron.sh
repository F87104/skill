#!/bin/bash
# Substack 自動いいね crontab セットアップスクリプト
#
# 1日300件いいね設定:
# - 8:00, 13:00, 20:00 の3回実行
# - 各回: 3モード × 34件 = 102件いいね + 5件フォロー
# - 合計: 306件いいね/日 + 15件フォロー/日

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_SCRIPT="$SCRIPT_DIR/run_auto.sh"

# 実行権限を付与
chmod +x "$RUN_SCRIPT"

echo "=== Substack 自動いいね crontab セットアップ ==="
echo ""
echo "以下のスケジュールで登録します:"
echo "  8:00  - 102件いいね + 5件フォロー"
echo "  13:00 - 102件いいね + 5件フォロー"
echo "  20:00 - 102件いいね + 5件フォロー"
echo "  合計: 約306件いいね/日 + 15件フォロー/日"
echo ""

# 既存のcrontabを保持しつつ追加
(crontab -l 2>/dev/null | grep -v "run_auto.sh"; \
 echo "0 8 * * * $RUN_SCRIPT"; \
 echo "0 13 * * * $RUN_SCRIPT"; \
 echo "0 20 * * * $RUN_SCRIPT") | crontab -

echo "✓ crontab登録完了！"
echo ""
echo "確認:"
crontab -l | grep "run_auto"
echo ""
echo "停止したい場合:"
echo "  crontab -e  # エディタで該当行を削除"
echo "  または"
echo "  crontab -l | grep -v 'run_auto' | crontab -"
echo ""
echo "ログ確認:"
echo "  tail -50 $SCRIPT_DIR/cron_log.txt"
