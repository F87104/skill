#!/usr/bin/env python3
"""
Substack 自動フォローモジュール（安全版 v2）
人間らしい動作パターンでアカウント凍結を防止する

エンドポイント:
  - POST /api/v1/feed/{user_id}/follow  (ユーザーフォロー)
  - POST /api/v1/reader/signup/pub      (Publication購読)
"""

import json
import time
import random
import logging
import os
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime, date

import requests

logger = logging.getLogger(__name__)


class DailyFollowLimiter:
    """フォロー専用の日次制限管理"""

    def __init__(self, state_file: str = "daily_limits.json"):
        self.state_file = state_file
        self.state = self._load()

    def _load(self) -> dict:
        try:
            with open(self.state_file, "r") as f:
                data = json.load(f)
                if data.get("date") != str(date.today()):
                    return self._new_state()
                return data
        except (FileNotFoundError, json.JSONDecodeError):
            return self._new_state()

    def _new_state(self) -> dict:
        return {
            "date": str(date.today()),
            "likes_today": 0,
            "follows_today": 0,
            "errors_today": 0,
            "rate_limits_today": 0,
            "sessions_today": 0,
            "paused_until": None,
        }

    def save(self):
        with open(self.state_file, "w") as f:
            json.dump(self.state, f, indent=2)

    def can_follow(self, daily_max: int = 5) -> bool:
        if self.is_paused():
            return False
        return self.state["follows_today"] < daily_max

    def record_follow(self):
        self.state["follows_today"] += 1
        self.save()

    def record_rate_limit(self):
        self.state["rate_limits_today"] += 1
        if self.state["rate_limits_today"] >= 2:
            self.pause_for_hours(3)
        self.save()

    def record_error(self):
        self.state["errors_today"] += 1
        if self.state["errors_today"] >= 3:
            self.pause_for_hours(6)
        self.save()

    def is_paused(self) -> bool:
        paused = self.state.get("paused_until")
        if paused:
            if datetime.fromisoformat(paused) > datetime.now():
                return True
            else:
                self.state["paused_until"] = None
                self.save()
        return False

    def pause_for_hours(self, hours: int):
        from datetime import timedelta
        until = datetime.now() + timedelta(hours=hours)
        self.state["paused_until"] = until.isoformat()
        logger.warning(f"安全停止: {until.strftime('%H:%M')}まで一時停止します")
        self.save()


class AutoFollower:
    """APIベースの自動フォロー（安全版）"""

    BASE_URL = "https://substack.com/api/v1"

    # User-Agentのバリエーション
    USER_AGENTS = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    ]

    def __init__(self, cookie: str, email: str = "", state_file: str = "follow_state.json",
                 daily_follow_limit: int = 5, **kwargs):
        self.cookie = cookie
        self.email = email
        self.state_file = state_file
        self.daily_follow_limit = daily_follow_limit

        # セッション設定
        self.session = requests.Session()
        self.session.cookies.set('substack.sid', cookie, domain='.substack.com')
        self.session.headers.update({
            'User-Agent': random.choice(self.USER_AGENTS),
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Origin': 'https://substack.com',
            'Referer': 'https://substack.com/',
            'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
        })

        # 状態管理
        self.state = self._load_state()

        # 日次制限（daily_limits.jsonを共有）
        self.daily_limiter = DailyFollowLimiter()

        # ユーザー情報
        self._user_id = None
        self._email = email

    def _load_state(self) -> dict:
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if 'followed_user_ids' not in data:
                        data['followed_user_ids'] = []
                    if 'subscribed_publication_ids' not in data:
                        data['subscribed_publication_ids'] = []
                    return data
            except (json.JSONDecodeError, IOError):
                pass
        return {
            'followed_user_ids': [],
            'subscribed_publication_ids': [],
            'followed_publications': [],
            'followed_users': [],
            'total_follows': 0,
            'last_run': None
        }

    def _save_state(self):
        self.state['last_run'] = datetime.now().isoformat()
        with open(self.state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)

    def _get_user_info(self) -> dict:
        try:
            self._human_wait(2.0, 5.0)
            resp = self.session.get(f'{self.BASE_URL}/user/profile/self', timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                self._user_id = data.get('id')
                if not self._email:
                    self._email = data.get('email', '')
                return data
        except Exception as e:
            logger.error(f"ユーザー情報取得エラー: {e}")
        return {}

    def _human_wait(self, min_sec: float = 5.0, max_sec: float = 15.0):
        """人間らしいランダム待機（正規分布）"""
        mean = (min_sec + max_sec) / 2
        std = (max_sec - min_sec) / 4
        delay = max(min_sec, random.gauss(mean, std))
        delay = min(delay, max_sec * 1.2)
        time.sleep(delay)

    def _page_transition_wait(self):
        """ページ遷移の待機（30-90秒）"""
        delay = max(30.0, random.gauss(50.0, 15.0))
        delay = min(delay, 120.0)
        time.sleep(delay)

    # ===== フォロー実行 =====

    def follow_user(self, user_id: int) -> bool:
        """ユーザーをフォローする（安全版）"""
        # 日次制限チェック
        if not self.daily_limiter.can_follow(self.daily_follow_limit):
            logger.warning(f"本日のフォロー上限({self.daily_follow_limit}件)に達しました")
            return False

        url = f"{self.BASE_URL}/feed/{user_id}/follow"
        payload = {"surface": "feed"}

        try:
            # 人間らしい待機（プロフィールを見ているフリ）
            self._human_wait(8.0, 20.0)
            resp = self.session.post(url, json=payload, timeout=15)

            if resp.status_code in [200, 201, 204]:
                logger.info(f"ユーザーフォロー成功: user_id={user_id}")
                if user_id not in self.state['followed_user_ids']:
                    self.state['followed_user_ids'].append(user_id)
                self.state['total_follows'] += 1
                self.daily_limiter.record_follow()
                return True
            elif resp.status_code == 429:
                logger.warning(f"レート制限: user_id={user_id}")
                self.daily_limiter.record_rate_limit()
                # 長時間待機
                time.sleep(random.uniform(300, 600))
                return False
            elif resp.status_code == 409:
                logger.info(f"既にフォロー済み: user_id={user_id}")
                if user_id not in self.state['followed_user_ids']:
                    self.state['followed_user_ids'].append(user_id)
                return True
            else:
                logger.warning(f"フォロー失敗: user_id={user_id}, status={resp.status_code}")
                self.daily_limiter.record_error()
                return False
        except requests.Timeout:
            logger.error(f"タイムアウト: user_id={user_id}")
            return False
        except Exception as e:
            logger.error(f"フォローエラー: user_id={user_id}, error={e}")
            return False

    def subscribe_publication(self, publication_id: int, source: str = "substack-feed-item") -> bool:
        """Publicationを購読する（安全版）"""
        if not self.daily_limiter.can_follow(self.daily_follow_limit):
            logger.warning(f"本日のフォロー上限({self.daily_follow_limit}件)に達しました")
            return False

        if not self._email:
            self._get_user_info()

        url = f"{self.BASE_URL}/reader/signup/pub"
        payload = {
            "publication_id": publication_id,
            "email": self._email,
            "source": source,
            "noWelcomeEmail": True,
            "first_url": "https://substack.com/",
            "first_referrer": "",
            "first_session_url": "https://substack.com/",
            "first_session_referrer": "",
            "current_url": "https://substack.com/",
            "current_referrer": "",
            "sessionStarted": int(time.time() * 1000),
            "landingReferrer": "",
            "landingUrl": "https://substack.com/",
            "referrer": ""
        }

        try:
            self._human_wait(8.0, 20.0)
            resp = self.session.post(url, json=payload, timeout=15)

            if resp.status_code in [200, 201, 204]:
                logger.info(f"Publication購読成功: pub_id={publication_id}")
                if publication_id not in self.state['subscribed_publication_ids']:
                    self.state['subscribed_publication_ids'].append(publication_id)
                self.state['total_follows'] += 1
                self.daily_limiter.record_follow()
                return True
            elif resp.status_code == 429:
                logger.warning(f"レート制限: pub_id={publication_id}")
                self.daily_limiter.record_rate_limit()
                time.sleep(random.uniform(300, 600))
                return False
            elif resp.status_code == 409:
                logger.info(f"既に購読済み: pub_id={publication_id}")
                if publication_id not in self.state['subscribed_publication_ids']:
                    self.state['subscribed_publication_ids'].append(publication_id)
                return True
            else:
                logger.warning(f"購読失敗: pub_id={publication_id}, status={resp.status_code}")
                self.daily_limiter.record_error()
                return False
        except requests.Timeout:
            logger.error(f"タイムアウト: pub_id={publication_id}")
            return False
        except Exception as e:
            logger.error(f"購読エラー: pub_id={publication_id}, error={e}")
            return False

    # ===== フォロー対象の取得 =====

    def _get_following_ids(self) -> set:
        """フォロー中のユーザーIDセットを取得"""
        try:
            self._human_wait(2.0, 5.0)
            resp = self.session.get(f'{self.BASE_URL}/feed/following', timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list):
                    return set(data)
        except Exception as e:
            logger.error(f"フォローリスト取得エラー: {e}")
        return set()

    def get_feed_users(self, limit: int = 30) -> List[Dict[str, Any]]:
        """おすすめフィードからフォロー候補のユーザーを取得"""
        following_ids = self._get_following_ids()
        logger.info(f"フォロー中: {len(following_ids)}件")

        url = f"{self.BASE_URL}/reader/feed"
        params = {"limit": limit}
        candidates = []
        seen_ids = set()

        try:
            self._human_wait(2.0, 5.0)
            resp = self.session.get(url, params=params, timeout=15)
            if resp.status_code != 200:
                logger.error(f"フィード取得失敗: {resp.status_code}")
                return []

            data = resp.json()
            items = data.get('items', data) if isinstance(data, dict) else data
            if not isinstance(items, list):
                return []

            for item in items:
                if not isinstance(item, dict):
                    continue

                if item.get('type') == 'userSuggestions':
                    for suggestion in item.get('userSuggestions', []):
                        user = suggestion.get('user', {})
                        pub = suggestion.get('publication', {})
                        uid = user.get('id')
                        if not uid or uid in seen_ids:
                            continue
                        if uid in following_ids:
                            continue

                        seen_ids.add(uid)
                        candidates.append({
                            'user_id': uid,
                            'name': user.get('name', ''),
                            'handle': user.get('handle', ''),
                            'publication_id': pub.get('id') if pub else None,
                            'subdomain': pub.get('subdomain', '') if pub else '',
                            'pub_name': pub.get('name', '') if pub else '',
                        })
                    continue

                post = item.get('post', {})
                if not post or not isinstance(post, dict):
                    continue

                bylines = post.get('publishedBylines', [])
                for byline in bylines:
                    if not isinstance(byline, dict):
                        continue
                    user_id = byline.get('id')
                    if not user_id or user_id in seen_ids:
                        continue
                    if user_id in following_ids:
                        continue

                    seen_ids.add(user_id)
                    pub = item.get('publication', {})
                    candidates.append({
                        'user_id': user_id,
                        'name': byline.get('name', ''),
                        'handle': byline.get('handle', ''),
                        'publication_id': pub.get('id') if pub else None,
                        'subdomain': pub.get('subdomain', '') if pub else '',
                        'pub_name': pub.get('name', '') if pub else '',
                    })

        except Exception as e:
            logger.error(f"フィードユーザー取得エラー: {e}")

        # ランダムにシャッフル（毎回同じ順番でフォローしない）
        random.shuffle(candidates)
        return candidates

    def get_activity_users(self) -> List[Dict[str, Any]]:
        """アクティビティからフォローバック候補を取得"""
        following_ids = self._get_following_ids()

        url = f"{self.BASE_URL}/activity-feed-web"
        candidates = []
        seen_ids = set()

        try:
            self._human_wait(2.0, 5.0)
            resp = self.session.get(url, timeout=15)
            if resp.status_code != 200:
                logger.error(f"アクティビティ取得失敗: {resp.status_code}")
                return []

            data = resp.json()
            activity_items = data.get('activityItems', [])

            users_list = data.get('users', [])
            users_map = {}
            if isinstance(users_list, list):
                for user in users_list:
                    if isinstance(user, dict) and user.get('id'):
                        users_map[user['id']] = user

            for item in activity_items:
                if not isinstance(item, dict):
                    continue

                if item.get('type') in ['follow', 'post_like', 'note_like', 'new_subscriber']:
                    sender_ids = item.get('recent_sender_ids', [])
                    for sender_id in sender_ids:
                        if sender_id in seen_ids:
                            continue
                        if sender_id in following_ids:
                            continue

                        seen_ids.add(sender_id)

                        user = users_map.get(sender_id)
                        if user:
                            candidates.append({
                                'user_id': sender_id,
                                'name': user.get('name', ''),
                                'handle': user.get('handle', ''),
                                'publication_id': None,
                                'subdomain': '',
                                'pub_name': '',
                            })
                        else:
                            user_info = self._get_user_profile(sender_id)
                            if user_info:
                                candidates.append(user_info)
                            self._human_wait(1.0, 3.0)

        except Exception as e:
            logger.error(f"アクティビティユーザー取得エラー: {e}")

        random.shuffle(candidates)
        return candidates

    def _get_user_profile(self, user_id: int) -> Optional[Dict[str, Any]]:
        """ユーザーのプロフィール情報を取得"""
        try:
            self._human_wait(2.0, 5.0)
            resp = self.session.get(f'{self.BASE_URL}/user/{user_id}/public_profile', timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                pub = data.get('primaryPublication', {})
                return {
                    'user_id': user_id,
                    'name': data.get('name', ''),
                    'handle': data.get('handle', ''),
                    'publication_id': pub.get('id') if pub else None,
                    'subdomain': pub.get('subdomain', '') if pub else '',
                    'pub_name': pub.get('name', '') if pub else '',
                }
        except Exception as e:
            logger.debug(f"プロフィール取得エラー: user_id={user_id}, {e}")
        return None

    # ===== メイン実行 =====

    def follow_from_feed(self, max_follows: int = 3, dry_run: bool = False) -> dict:
        """
        おすすめフィードからユーザーをフォロー（安全版）

        Args:
            max_follows: 最大フォロー数（デフォルト3件に削減）
            dry_run: ドライラン
        """
        results = {"success": 0, "skip": 0, "fail": 0, "targets": []}

        # 日次制限チェック
        if not self.daily_limiter.can_follow(self.daily_follow_limit):
            logger.warning("本日のフォロー上限に達しています。スキップします。")
            return results

        if self.daily_limiter.is_paused():
            logger.warning("安全停止中です。スキップします。")
            return results

        logger.info("おすすめフィードからフォロー候補を取得中...")
        candidates = self.get_feed_users(limit=30)

        if not candidates:
            logger.info("フォロー候補が見つかりませんでした")
            return results

        logger.info(f"フォロー候補: {len(candidates)}件")

        followed = 0
        for candidate in candidates:
            if followed >= max_follows:
                break

            if not self.daily_limiter.can_follow(self.daily_follow_limit):
                logger.warning("本日のフォロー上限に達しました。停止します。")
                break

            user_id = candidate.get('user_id')
            name = candidate.get('name', '不明')

            if not user_id:
                continue

            if user_id in self.state.get('followed_user_ids', []):
                results['skip'] += 1
                continue

            if dry_run:
                logger.info(f"  [DRY] フォロー対象: {name} (user_id={user_id})")
                results['targets'].append(candidate)
                results['success'] += 1
                followed += 1
                continue

            # ユーザーフォロー実行（失敗時はPublication購読にフォールバック）
            success = self.follow_user(user_id)
            if not success:
                pub_id = candidate.get('publication_id')
                if not pub_id:
                    profile = self._get_user_profile(user_id)
                    if profile:
                        pub_id = profile.get('publication_id')
                if pub_id:
                    logger.info(f"  フォールバック: Publication購読を試行 (pub_id={pub_id})")
                    success = self.subscribe_publication(pub_id)

            if success:
                results['success'] += 1
                results['targets'].append(candidate)
                followed += 1
                logger.info(f"  フォロー成功: {name}")
            else:
                results['fail'] += 1
                logger.warning(f"  フォロー失敗: {name}")
                if self.daily_limiter.is_paused():
                    logger.warning("安全停止が発動しました。処理を中断します。")
                    break

            # フォロー間の長い待機（ページ遷移のフリ）
            self._page_transition_wait()

        self._save_state()
        return results

    def follow_back(self, max_follows: int = 2, dry_run: bool = False) -> dict:
        """
        いいねしてくれた人をフォローバック（安全版）

        Args:
            max_follows: 最大フォロー数（デフォルト2件に削減）
            dry_run: ドライラン
        """
        results = {"success": 0, "skip": 0, "fail": 0, "targets": []}

        if not self.daily_limiter.can_follow(self.daily_follow_limit):
            logger.warning("本日のフォロー上限に達しています。スキップします。")
            return results

        if self.daily_limiter.is_paused():
            logger.warning("安全停止中です。スキップします。")
            return results

        logger.info("アクティビティからフォローバック候補を取得中...")
        candidates = self.get_activity_users()

        if not candidates:
            logger.info("フォローバック対象が見つかりませんでした")
            return results

        logger.info(f"フォローバック候補: {len(candidates)}件")

        followed = 0
        for candidate in candidates:
            if followed >= max_follows:
                break

            if not self.daily_limiter.can_follow(self.daily_follow_limit):
                logger.warning("本日のフォロー上限に達しました。停止します。")
                break

            user_id = candidate.get('user_id')
            name = candidate.get('name', '不明')

            if not user_id:
                continue

            if user_id in self.state.get('followed_user_ids', []):
                results['skip'] += 1
                continue

            if dry_run:
                logger.info(f"  [DRY] フォローバック対象: {name} (user_id={user_id})")
                results['targets'].append(candidate)
                results['success'] += 1
                followed += 1
                continue

            success = self.follow_user(user_id)
            if not success:
                pub_id = candidate.get('publication_id')
                if not pub_id:
                    profile = self._get_user_profile(user_id)
                    if profile:
                        pub_id = profile.get('publication_id')
                if pub_id:
                    logger.info(f"  フォールバック: Publication購読を試行 (pub_id={pub_id})")
                    success = self.subscribe_publication(pub_id)

            if success:
                results['success'] += 1
                results['targets'].append(candidate)
                followed += 1
                logger.info(f"  フォローバック成功: {name}")
            else:
                results['fail'] += 1
                logger.warning(f"  フォローバック失敗: {name}")
                if self.daily_limiter.is_paused():
                    logger.warning("安全停止が発動しました。処理を中断します。")
                    break

            self._page_transition_wait()

        self._save_state()
        return results


def main():
    """テスト用メイン関数"""
    import argparse

    parser = argparse.ArgumentParser(description='Substack 自動フォローツール（安全版）')
    parser.add_argument('--cookie', '-c', required=True, help='substack.sid クッキー値')
    parser.add_argument('--email', '-e', default='', help='メールアドレス')
    parser.add_argument('--mode', '-m', choices=['feed', 'followback', 'all'], default='all')
    parser.add_argument('--max-follows', '-n', type=int, default=3, help='最大フォロー数')
    parser.add_argument('--dry-run', '-d', action='store_true', help='ドライラン')

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    follower = AutoFollower(
        cookie=args.cookie,
        email=args.email
    )

    if args.mode in ['feed', 'all']:
        print("\n=== フィードからフォロー ===")
        results = follower.follow_from_feed(
            max_follows=args.max_follows,
            dry_run=args.dry_run
        )
        print(f"  成功: {results['success']}件, スキップ: {results['skip']}件, 失敗: {results['fail']}件")

    if args.mode in ['followback', 'all']:
        print("\n=== フォローバック ===")
        results = follower.follow_back(
            max_follows=args.max_follows,
            dry_run=args.dry_run
        )
        print(f"  成功: {results['success']}件, スキップ: {results['skip']}件, 失敗: {results['fail']}件")


if __name__ == '__main__':
    main()
