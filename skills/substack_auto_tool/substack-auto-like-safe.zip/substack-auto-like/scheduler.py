#!/usr/bin/env python3
"""
Substack 自動いいね＆フォロー スケジューラー（安全版 v2）
人間らしい動作パターンで定期実行する
"""

import time
import json
import random
import logging
import signal
import sys
from datetime import datetime, timedelta
from pathlib import Path

from substack_client import SubstackClient
from auto_liker import AutoLiker

logger = logging.getLogger(__name__)


class Scheduler:
    """定期実行スケジューラー（安全版）"""

    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self.config = self._load_config()
        self.running = True

        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _load_config(self) -> dict:
        """設定読み込み"""
        path = Path(self.config_path)
        if not path.exists():
            raise FileNotFoundError(f"設定ファイルが見つかりません: {self.config_path}")

        with open(path, "r", encoding="utf-8") as f:
            config = json.load(f)

        # 安全なデフォルト設定
        config.setdefault("schedule_interval_minutes", 480)  # 8時間間隔
        config.setdefault("max_likes_per_mode", 8)
        config.setdefault("max_follows", 3)
        config.setdefault("daily_like_limit", 50)
        config.setdefault("daily_follow_limit", 5)
        config.setdefault("modes", ["recommend", "follower", "return"])
        config.setdefault("enable_follow", True)
        config.setdefault("quiet_hours_start", 0)
        config.setdefault("quiet_hours_end", 8)

        return config

    def _signal_handler(self, signum, frame):
        logger.info("停止シグナルを受信しました。終了します...")
        self.running = False

    def _is_quiet_hours(self) -> bool:
        """静粛時間帯かチェック"""
        now = datetime.now()
        start = self.config.get("quiet_hours_start", 0)
        end = self.config.get("quiet_hours_end", 8)

        if start > end:
            return now.hour >= start or now.hour < end
        else:
            return start <= now.hour < end

    def _randomize_interval(self, base_minutes: int) -> int:
        """実行間隔にランダム性を追加（±30分）"""
        jitter = random.randint(-30, 30)
        return max(60, base_minutes + jitter)  # 最低60分

    def run(self):
        """スケジューラーを開始"""
        cookie = self.config.get("cookie")
        if not cookie or cookie == "YOUR_SUBSTACK_SID_COOKIE_HERE":
            logger.error("クッキーが設定されていません。config.jsonを確認してください。")
            sys.exit(1)

        base_interval = self.config.get("schedule_interval_minutes", 480)
        max_likes = self.config.get("max_likes_per_mode", 8)
        max_follows = self.config.get("max_follows", 3)
        daily_like_limit = self.config.get("daily_like_limit", 50)
        daily_follow_limit = self.config.get("daily_follow_limit", 5)
        enable_follow = self.config.get("enable_follow", True)

        logger.info("=" * 60)
        logger.info("Substack 自動いいね＆フォロー スケジューラー起動（安全版）")
        logger.info(f"実行間隔: 約{base_interval}分（±30分のランダム）")
        logger.info(f"最大いいね数/モード/回: {max_likes}件")
        logger.info(f"1日のいいね上限: {daily_like_limit}件")
        logger.info(f"1日のフォロー上限: {daily_follow_limit}件")
        logger.info(f"フォロー: {'有効' if enable_follow else '無効'} ({max_follows}件/回)")
        logger.info(f"静粛時間: {self.config.get('quiet_hours_start', 0)}:00 - "
                   f"{self.config.get('quiet_hours_end', 8)}:00")
        logger.info("=" * 60)

        while self.running:
            # 静粛時間チェック
            if self._is_quiet_hours():
                logger.info("静粛時間帯です。次の実行まで待機します。")
                time.sleep(600)  # 10分待機
                continue

            try:
                # クライアント初期化
                client = SubstackClient(
                    session_cookie=cookie,
                    daily_like_limit=daily_like_limit,
                    daily_follow_limit=daily_follow_limit,
                )

                if not client.test_connection():
                    logger.error("接続失敗。クッキーの有効期限が切れている可能性があります。")
                    time.sleep(base_interval * 60)
                    continue

                # 日次状況確認
                status = client.get_daily_status()
                logger.info(f"本日の残り: いいね={status['likes_remaining']}件, "
                          f"フォロー={status['follows_remaining']}件")

                if status["is_paused"]:
                    logger.warning("安全停止中です。次の実行まで待機します。")
                    time.sleep(base_interval * 60)
                    continue

                # === いいね実行 ===
                liker = AutoLiker(client, state_file=self.config.get("state_file", "like_state.json"))

                dry_run = self.config.get("dry_run", False)
                like_results = liker.run_all(max_likes_per_mode=max_likes, dry_run=dry_run)

                total_liked = sum(len(r["liked"]) for r in like_results.values()) if like_results else 0
                logger.info(f"いいね完了: {total_liked}件")

                # === フォロー実行 ===
                if enable_follow:
                    try:
                        from auto_follow import AutoFollower

                        # いいねとフォローの間に長い休憩
                        pause = random.uniform(120, 300)
                        logger.info(f"フォロー前の休憩: {int(pause)}秒...")
                        time.sleep(pause)

                        follower = AutoFollower(
                            cookie=cookie,
                            email=self.config.get('email', ''),
                            state_file=self.config.get("follow_state_file", "follow_state.json"),
                            daily_follow_limit=daily_follow_limit,
                        )

                        follow_result = follower.follow_from_feed(
                            max_follows=max_follows,
                            dry_run=dry_run
                        )
                        logger.info(f"フォロー完了: {follow_result['success']}件")

                        # フォローバックも実行（少なめに）
                        followback_result = follower.follow_back(
                            max_follows=max(2, max_follows // 2),
                            dry_run=dry_run
                        )
                        logger.info(f"フォローバック完了: {followback_result['success']}件")
                    except ImportError:
                        logger.warning("auto_follow.py が見つかりません。フォロー機能スキップ。")
                    except Exception as e:
                        logger.error(f"フォローエラー: {e}")

                # 次の実行間隔をランダム化
                interval = self._randomize_interval(base_interval)
                logger.info(f"次の実行: {interval}分後")

            except Exception as e:
                logger.error(f"実行エラー: {e}", exc_info=True)
                interval = base_interval

            # 次の実行まで待機
            wait_until = datetime.now() + timedelta(minutes=interval)
            while self.running and datetime.now() < wait_until:
                time.sleep(10)

        logger.info("スケジューラーを停止しました。")


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Substack 自動いいね＆フォロー スケジューラー（安全版）")
    parser.add_argument("--config", default="config.json", help="設定ファイルパス")
    parser.add_argument("--verbose", "-v", action="store_true", help="詳細ログ")

    args = parser.parse_args()

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("scheduler.log", encoding="utf-8"),
        ]
    )

    scheduler = Scheduler(config_path=args.config)
    scheduler.run()


if __name__ == "__main__":
    main()
