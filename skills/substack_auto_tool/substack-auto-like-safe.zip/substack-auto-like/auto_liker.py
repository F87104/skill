"""
Substack 自動いいねエンジン（安全版 v2）
人間らしい動作パターンでアカウント凍結を防止する
3つのモード：おすすめ、フォロワー、お返し
"""

import json
import logging
import time
import random
from typing import Dict, List, Set, Optional, Any
from datetime import datetime, timedelta
from pathlib import Path

from substack_client import SubstackClient, HumanBehavior

logger = logging.getLogger(__name__)


class AutoLiker:
    """Substack自動いいねエンジン（安全版）"""

    def __init__(self, client: SubstackClient, state_file: str = "like_state.json"):
        self.client = client
        self.state_file = Path(state_file)
        self.state = self._load_state()
        self.human = HumanBehavior()

    def _load_state(self) -> Dict[str, Any]:
        """保存された状態を読み込む"""
        if self.state_file.exists():
            try:
                with open(self.state_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass

        return {
            "liked_post_ids": [],
            "liked_note_ids": [],
            "returned_likes_to": [],
            "last_run": None,
            "stats": {
                "total_likes_given": 0,
                "recommend_likes": 0,
                "follower_likes": 0,
                "return_likes": 0,
            }
        }

    def _save_state(self):
        """状態を保存する"""
        self.state["last_run"] = datetime.now().isoformat()
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.state_file, "w", encoding="utf-8") as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)

    def _is_already_liked(self, item_id: int, item_type: str = "post") -> bool:
        """既にいいね済みかチェック"""
        if item_type == "note":
            return item_id in self.state["liked_note_ids"]
        return item_id in self.state["liked_post_ids"]

    def _record_like(self, item_id: int, item_type: str = "post", mode: str = "recommend"):
        """いいねを記録"""
        if item_type == "note":
            if item_id not in self.state["liked_note_ids"]:
                self.state["liked_note_ids"].append(item_id)
        else:
            if item_id not in self.state["liked_post_ids"]:
                self.state["liked_post_ids"].append(item_id)

        self.state["stats"]["total_likes_given"] += 1
        if mode == "recommend":
            self.state["stats"]["recommend_likes"] += 1
        elif mode == "follower":
            self.state["stats"]["follower_likes"] += 1
        elif mode == "return":
            self.state["stats"]["return_likes"] += 1

        self._save_state()

    def _extract_item_info(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """フィードアイテムから必要な情報を抽出"""
        result = {
            "id": None,
            "type": "post",
            "title": "",
            "author": "",
            "author_id": None,
            "publication": "",
            "already_liked": False,
        }

        item_type = item.get("type", "")

        if item_type == "comment" or ("comment" in item and item.get("comment") is not None):
            comment = item["comment"]
            result["id"] = comment.get("id")
            result["type"] = "comment"
            result["title"] = (comment.get("body", "") or "")[:50]
            result["already_liked"] = comment.get("reader_liked", False)
            result["author"] = comment.get("name", "")
            result["author_id"] = comment.get("user_id")
            pub = item.get("publication")
            if pub and isinstance(pub, dict):
                result["publication"] = pub.get("name", "")

        elif item_type == "post" or ("post" in item and item.get("post") is not None):
            post = item["post"]
            result["id"] = post.get("id")
            result["type"] = "post"
            result["title"] = post.get("title", "") or ""
            result["already_liked"] = post.get("reader_liked", False)
            pub_bylines = post.get("publishedBylines", [])
            if pub_bylines and isinstance(pub_bylines, list) and len(pub_bylines) > 0:
                result["author"] = pub_bylines[0].get("name", "")
                result["author_id"] = pub_bylines[0].get("id")
            pub = item.get("publication")
            if pub and isinstance(pub, dict):
                result["publication"] = pub.get("name", "")
            else:
                result["publication"] = post.get("publication_name", "")

        elif "note" in item and item.get("note") is not None:
            note = item["note"]
            result["id"] = note.get("id")
            result["title"] = (note.get("body", "") or "")[:50]
            result["type"] = "note"
            result["already_liked"] = note.get("reader_liked", False)
            result["author"] = note.get("author_name", "") or note.get("name", "")
            result["author_id"] = note.get("author_id") or note.get("user_id")

        elif "id" in item:
            result["id"] = item.get("id") or item.get("post_id")
            result["type"] = item_type or "post"
            result["title"] = (item.get("title", "") or item.get("body", "") or "")[:50]
            result["already_liked"] = item.get("reader_liked", False)
            result["author"] = item.get("author_name", "") or item.get("name", "")
            result["author_id"] = item.get("author_id") or item.get("user_id")
            result["publication"] = item.get("publication_name", "")

        elif "items" in item:
            items = item["items"]
            if items:
                return self._extract_item_info(items[0])

        return result

    # ===== モード1: おすすめフィードへの自動いいね =====

    def like_recommended(self, max_likes: int = 8, dry_run: bool = False) -> Dict[str, Any]:
        """
        おすすめフィードの投稿にいいねする（安全版）

        Args:
            max_likes: 最大いいね数（デフォルト8件に削減）
            dry_run: ドライラン
        """
        logger.info(f"=== おすすめフィードへの自動いいね開始 (最大{max_likes}件) ===")
        results = {"liked": [], "skipped": [], "failed": [], "errors": []}

        # 日次制限チェック
        if not self.client.daily_limiter.can_like(self.client.daily_like_limit):
            logger.warning("本日のいいね上限に達しています。スキップします。")
            results["errors"].append("日次上限到達")
            return results

        # セッション開始の待機（ページを開いたフリ）
        self.human.session_start()

        feed_items = self.client.get_feed(limit=max_likes * 3)

        if not feed_items:
            logger.warning("フィードが空です。")
            results["errors"].append("フィードが空です")
            return results

        likes_count = 0
        for item in feed_items:
            if likes_count >= max_likes:
                break

            # 日次制限の再チェック
            if not self.client.daily_limiter.can_like(self.client.daily_like_limit):
                logger.warning("本日のいいね上限に達しました。停止します。")
                break

            info = self._extract_item_info(item)
            if not info["id"]:
                continue

            # 既にいいね済みチェック
            if info["already_liked"] or self._is_already_liked(info["id"], info["type"]):
                results["skipped"].append(info)
                logger.debug(f"スキップ（いいね済み）: {info['title']}")
                continue

            # 人間らしいスキップ（25%の確率で意図的にスキップ）
            if not dry_run and self.human.should_skip(0.25):
                logger.debug(f"スキップ（ランダム）: {info['title']}")
                results["skipped"].append(info)
                continue

            if dry_run:
                logger.info(f"[DRY RUN] いいね対象: {info['title']} by {info['author']}")
                results["liked"].append(info)
                likes_count += 1
                continue

            # いいね実行（内部で人間らしい待機が入る）
            success = self.client.like_item(item)
            if success:
                self._record_like(info["id"], info["type"], "recommend")
                results["liked"].append(info)
                likes_count += 1
                logger.info(f"いいね成功: {info['title']} by {info['author']}")
            else:
                results["failed"].append(info)
                logger.warning(f"いいね失敗: {info['title']}")
                # 失敗したら少し長めに待機
                if self.client.daily_limiter.is_paused():
                    logger.warning("安全停止が発動しました。処理を中断します。")
                    break

        logger.info(f"おすすめいいね完了: 成功={len(results['liked'])}, "
                   f"スキップ={len(results['skipped'])}, 失敗={len(results['failed'])}")
        return results

    # ===== モード2: フォロワーの投稿への自動いいね =====

    def like_follower_posts(self, max_likes: int = 8, dry_run: bool = False) -> Dict[str, Any]:
        """フォロワーの投稿にいいねする（安全版）"""
        logger.info(f"=== フォロワー投稿への自動いいね開始 (最大{max_likes}件) ===")
        results = {"liked": [], "skipped": [], "failed": [], "errors": []}

        if not self.client.daily_limiter.can_like(self.client.daily_like_limit):
            logger.warning("本日のいいね上限に達しています。スキップします。")
            results["errors"].append("日次上限到達")
            return results

        self.human.session_start()

        follower_items = self.client.get_follower_posts(limit=max_likes * 3)

        if not follower_items:
            logger.info("フォロワー専用フィードが利用不可。通常フィードを使用します。")
            follower_items = self.client.get_feed(limit=max_likes * 3)

        if not follower_items:
            logger.warning("フォロワーの投稿が見つかりません。")
            results["errors"].append("フォロワーの投稿が見つかりません")
            return results

        likes_count = 0
        for item in follower_items:
            if likes_count >= max_likes:
                break

            if not self.client.daily_limiter.can_like(self.client.daily_like_limit):
                logger.warning("本日のいいね上限に達しました。停止します。")
                break

            info = self._extract_item_info(item)
            if not info["id"]:
                continue

            if info["already_liked"] or self._is_already_liked(info["id"], info["type"]):
                results["skipped"].append(info)
                continue

            # 人間らしいスキップ
            if not dry_run and self.human.should_skip(0.20):
                results["skipped"].append(info)
                continue

            if dry_run:
                logger.info(f"[DRY RUN] フォロワーいいね対象: {info['title']} by {info['author']}")
                results["liked"].append(info)
                likes_count += 1
                continue

            success = self.client.like_item(item)
            if success:
                self._record_like(info["id"], info["type"], "follower")
                results["liked"].append(info)
                likes_count += 1
                logger.info(f"フォロワーいいね成功: {info['title']} by {info['author']}")
            else:
                results["failed"].append(info)
                if self.client.daily_limiter.is_paused():
                    logger.warning("安全停止が発動しました。処理を中断します。")
                    break

        logger.info(f"フォロワーいいね完了: 成功={len(results['liked'])}, "
                   f"スキップ={len(results['skipped'])}, 失敗={len(results['failed'])}")
        return results

    # ===== モード3: お返しいいね =====

    def like_back(self, max_likes: int = 5, dry_run: bool = False) -> Dict[str, Any]:
        """いいねしてくれた人の投稿にお返しいいねする（安全版）"""
        logger.info(f"=== お返しいいね開始 (最大{max_likes}件) ===")
        results = {"liked": [], "skipped": [], "failed": [], "errors": []}

        if not self.client.daily_limiter.can_like(self.client.daily_like_limit):
            logger.warning("本日のいいね上限に達しています。スキップします。")
            results["errors"].append("日次上限到達")
            return results

        activity_data = self.client.get_activity(limit=100)

        if not activity_data or not activity_data.get("activityItems"):
            logger.warning("アクティビティが取得できません。")
            results["errors"].append("アクティビティが取得できません")
            return results

        likers = self._extract_likers(activity_data)
        logger.info(f"いいねしてくれたユーザー: {len(likers)}人")

        if not likers:
            logger.info("新しいいいねはありません。")
            return results

        likes_count = 0
        for liker in likers:
            if likes_count >= max_likes:
                break

            if not self.client.daily_limiter.can_like(self.client.daily_like_limit):
                logger.warning("本日のいいね上限に達しました。停止します。")
                break

            user_id = liker.get("user_id")
            username = liker.get("username", "")

            if user_id in self.state["returned_likes_to"]:
                results["skipped"].append(liker)
                continue

            # ユーザーの投稿を取得（ページ遷移のフリ）
            self.human.page_transition()
            user_posts = self._get_user_recent_posts(user_id, username)

            if not user_posts:
                logger.debug(f"ユーザー {username} の投稿が見つかりません")
                continue

            for post in user_posts[:1]:
                post_info = self._extract_item_info(post)

                if not post_info["id"]:
                    continue

                if self._is_already_liked(post_info["id"], post_info["type"]):
                    results["skipped"].append(post_info)
                    continue

                if dry_run:
                    logger.info(f"[DRY RUN] お返しいいね対象: {post_info['title']} by {username}")
                    results["liked"].append(post_info)
                    likes_count += 1
                    continue

                success = self.client.like_item(post)
                if success:
                    self._record_like(post_info["id"], post_info["type"], "return")
                    results["liked"].append(post_info)
                    likes_count += 1

                    if user_id not in self.state["returned_likes_to"]:
                        self.state["returned_likes_to"].append(user_id)
                    self._save_state()

                    logger.info(f"お返しいいね成功: {post_info['title']} by {username}")
                else:
                    results["failed"].append(post_info)
                    if self.client.daily_limiter.is_paused():
                        logger.warning("安全停止が発動しました。処理を中断します。")
                        break

        logger.info(f"お返しいいね完了: 成功={len(results['liked'])}, "
                   f"スキップ={len(results['skipped'])}, 失敗={len(results['failed'])}")
        return results

    def _extract_likers(self, activity_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """アクティビティからいいねしてくれたユーザーを抽出"""
        likers = []
        seen_users = set()

        activity_items = activity_data.get("activityItems", [])
        users_list = activity_data.get("users", [])
        users_map = {}
        if isinstance(users_list, list):
            for u in users_list:
                if isinstance(u, dict) and u.get("id"):
                    users_map[u["id"]] = u
        elif isinstance(users_list, dict):
            users_map = users_list

        for item in activity_items:
            if not isinstance(item, dict):
                continue

            activity_type = item.get("type", "")

            if activity_type in ["post_like", "note_like", "like", "reaction", "heart"]:
                sender_ids = item.get("recent_sender_ids", [])

                for sender_id in sender_ids:
                    if sender_id and sender_id not in seen_users:
                        seen_users.add(sender_id)
                        user_info = users_map.get(sender_id, {})
                        username = user_info.get("handle") or user_info.get("name", f"user_{sender_id}")
                        likers.append({
                            "user_id": sender_id,
                            "username": username,
                            "timestamp": item.get("created_at", ""),
                        })

        return likers

    def _get_user_recent_posts(self, user_id: int, username: str = "") -> List[Dict[str, Any]]:
        """ユーザーの最新投稿を取得"""
        url = f"{self.client.BASE_URL}/reader/feed/profile/{user_id}"
        params = {"limit": 5}

        try:
            response = self.client._request("GET", url, params=params)
            data = response.json()
            items = data.get("items", data) if isinstance(data, dict) else data
            return items if isinstance(items, list) else []
        except Exception as e:
            logger.debug(f"ユーザー {username}({user_id}) の投稿取得失敗: {e}")
            return []

    # ===== 全モード実行 =====

    def run_all(self, max_likes_per_mode: int = 8, dry_run: bool = False) -> Dict[str, Any]:
        """
        全モードを実行（安全版）

        Args:
            max_likes_per_mode: 各モードの最大いいね数（デフォルト8件）
            dry_run: ドライラン
        """
        logger.info("=" * 60)
        logger.info(f"Substack 自動いいね開始（安全版）- {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"モード: 全て | 最大いいね数/モード: {max_likes_per_mode}")

        # 日次状況表示
        status = self.client.get_daily_status()
        logger.info(f"本日の残り: いいね={status['likes_remaining']}件, "
                   f"フォロー={status['follows_remaining']}件")
        if status["is_paused"]:
            logger.warning("現在安全停止中です。処理をスキップします。")
            return {}

        if dry_run:
            logger.info("*** ドライランモード（実際にはいいねしません）***")
        logger.info("=" * 60)

        results = {}

        # モード1: おすすめ
        results["recommend"] = self.like_recommended(max_likes_per_mode, dry_run)

        # モード間の長い休憩（ページ遷移のフリ）
        if not dry_run:
            logger.info("モード切替: 休憩中...")
            self.human.page_transition()

        # モード2: フォロワー
        results["follower"] = self.like_follower_posts(max_likes_per_mode, dry_run)

        if not dry_run:
            logger.info("モード切替: 休憩中...")
            self.human.page_transition()

        # モード3: お返し（少なめに）
        return_max = max(3, max_likes_per_mode // 2)
        results["return"] = self.like_back(return_max, dry_run)

        # サマリー出力
        total_liked = sum(len(r["liked"]) for r in results.values())
        total_skipped = sum(len(r["skipped"]) for r in results.values())
        total_failed = sum(len(r["failed"]) for r in results.values())

        # 最終日次状況
        final_status = self.client.get_daily_status()

        logger.info("=" * 60)
        logger.info("実行結果サマリー:")
        logger.info(f"  いいね成功: {total_liked}件")
        logger.info(f"  スキップ: {total_skipped}件")
        logger.info(f"  失敗: {total_failed}件")
        logger.info(f"  累計いいね数: {self.state['stats']['total_likes_given']}件")
        logger.info(f"  本日残り: いいね={final_status['likes_remaining']}件")
        logger.info("=" * 60)

        return results

    def get_stats(self) -> Dict[str, Any]:
        """統計情報を取得"""
        return {
            "stats": self.state["stats"],
            "last_run": self.state["last_run"],
            "total_liked_posts": len(self.state["liked_post_ids"]),
            "total_liked_notes": len(self.state["liked_note_ids"]),
            "total_returned_users": len(self.state["returned_likes_to"]),
            "daily_status": self.client.get_daily_status() if hasattr(self, 'client') else {},
        }
