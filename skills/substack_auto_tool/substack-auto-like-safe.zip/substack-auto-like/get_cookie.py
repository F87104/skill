#!/usr/bin/env python3
"""
Substack セッションクッキー取得ヘルパー

ブラウザからクッキーを取得する方法を案内し、
メールアドレスとマジックリンクでの認証もサポート
"""

import requests
import json
import sys


def get_cookie_via_email(email: str) -> dict:
    """
    メールアドレスでマジックリンクを送信

    Args:
        email: Substackに登録されたメールアドレス

    Returns:
        結果の辞書
    """
    url = "https://substack.com/api/v1/login"
    payload = {
        "email": email,
        "redirect": "/",
        "for_pub": "",
    }

    try:
        response = requests.post(url, json=payload)
        if response.status_code == 200:
            return {
                "success": True,
                "message": "マジックリンクをメールに送信しました。メール内のリンクをクリックしてログインしてください。"
            }
        else:
            return {
                "success": False,
                "message": f"エラー: {response.status_code} - {response.text}"
            }
    except Exception as e:
        return {
            "success": False,
            "message": f"リクエストエラー: {e}"
        }


def print_manual_instructions():
    """手動でのクッキー取得方法を表示"""
    instructions = """
╔══════════════════════════════════════════════════════════════╗
║          Substack セッションクッキー取得ガイド              ║
╚══════════════════════════════════════════════════════════════╝

【方法1: Chrome DevToolsから取得（推奨）】

  1. Chrome で https://substack.com にアクセスしてログイン
  2. F12 キーで DevTools を開く
  3. 「Application」タブをクリック
  4. 左側メニューの「Cookies」→「https://substack.com」を選択
  5. 「substack.sid」の Value 列の値をコピー

  ※ 値は通常 "s%3A..." で始まる長い文字列です

【方法2: DevTools Console から取得】

  1. Chrome で https://substack.com にアクセスしてログイン
  2. F12 キーで DevTools を開く
  3. 「Console」タブで以下を実行:

     document.cookie.split(';').find(c => c.trim().startsWith('substack.sid'))

  4. 表示された "substack.sid=..." の = 以降の値をコピー

【方法3: Firefox から取得】

  1. Firefox で https://substack.com にアクセスしてログイン
  2. F12 キーで DevTools を開く
  3. 「ストレージ」タブ → 「Cookie」→「https://substack.com」
  4. 「substack.sid」の値をコピー

【取得後の使用方法】

  # コマンドラインで直接指定:
  python main.py --cookie "s%3A..." --mode all --dry-run

  # 設定ファイルに保存:
  # config.json の "cookie" フィールドに値を設定

【注意事項】

  - クッキーの有効期限は通常数週間〜数ヶ月です
  - 有効期限が切れた場合は再取得が必要です
  - クッキーは他人に共有しないでください（アカウントへのアクセスを許可することになります）
  - ログアウトするとクッキーは無効になります
"""
    print(instructions)


def validate_cookie(cookie: str) -> bool:
    """クッキーの有効性を検証"""
    from substack_client import SubstackClient

    client = SubstackClient(session_cookie=cookie)
    return client.test_connection()


def main():
    print("\n=== Substack セッションクッキー取得ヘルパー ===\n")
    print("1. 手動取得方法を表示")
    print("2. メールでマジックリンクを送信")
    print("3. クッキーの有効性を検証")
    print("0. 終了")

    choice = input("\n選択してください [0-3]: ").strip()

    if choice == "1":
        print_manual_instructions()
    elif choice == "2":
        email = input("Substackに登録されたメールアドレス: ").strip()
        if email:
            result = get_cookie_via_email(email)
            print(f"\n{result['message']}")
        else:
            print("メールアドレスが入力されていません。")
    elif choice == "3":
        cookie = input("substack.sid の値を入力: ").strip()
        if cookie:
            print("検証中...")
            if validate_cookie(cookie):
                print("✓ クッキーは有効です！")
            else:
                print("✗ クッキーは無効です。再取得してください。")
        else:
            print("クッキーが入力されていません。")
    elif choice == "0":
        sys.exit(0)
    else:
        print("無効な選択です。")


if __name__ == "__main__":
    main()
